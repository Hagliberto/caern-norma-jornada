// [widgets/norma_screen.dart]

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_state.dart';
import 'chapter_expander.dart';

class NormaScreen extends StatefulWidget {
  const NormaScreen({super.key});

  @override
  State<NormaScreen> createState() => _NormaScreenState();
}

class _NormaScreenState extends State<NormaScreen> {
  @override
  void initState() {
    super.initState();
    // CORREÇÃO: Re-adiciona a chamada de carregamento.
    // Isso garante que o carregamento dos assets é iniciado imediatamente
    // quando a tela de Norma é construída pela primeira vez.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppState>(context, listen: false).loadFromAssets();
    });
  }

  // Função que monta a mensagem consolidada e compartilha (Lote) - MANTIDA
  void _shareBatchContent(
      BuildContext context, List<NormaContent> selectedContent) async {
    if (selectedContent.isEmpty) return;

    final StringBuffer buffer = StringBuffer();
    buffer.write('*Norma – Jornada e Frequência CAERN*\n\n');
    buffer.write(
        '--- Conteúdo Selecionado (${selectedContent.length} itens) ---\n');
    buffer.write('-----------------------------------------------------\n');

    for (var content in selectedContent) {
      buffer.write('\n[${content.type}] *Ref: ${content.reference}*\n');
      buffer.write('${content.content}\n');
      buffer.write('-----------------------------------------------------\n');
    }

    final String textToShare = buffer.toString();
    final String encodedText = Uri.encodeComponent(textToShare);
    final whatsappUrl = Uri.parse('whatsapp://send?text=$encodedText');
    final fallbackUrl = Uri.parse('https://wa.me/?text=$encodedText');

    try {
      if (await canLaunchUrl(whatsappUrl)) {
        await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(fallbackUrl)) {
        await launchUrl(fallbackUrl, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível abrir o WhatsApp.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao tentar compartilhar: $e')),
      );
    }

    Provider.of<AppState>(context, listen: false).clearSelection();
  }

  @override
// [widgets/norma_screen.dart] - Dentro da classe _NormaScreenState

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final chapters = appState.rawChapters;

    // NOVO: Define apenas o conteúdo que será exibido em caso de erro/carregamento/vazio
    Widget nonListContent;
    if (appState.isLoading) {
      nonListContent = const Center(child: CircularProgressIndicator());
    } else if (appState.error != null) {
      nonListContent = Center(
        child: Text(
          'Erro ao carregar a norma:\n${appState.error}',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.red),
        ),
      );
    } else if (chapters.isEmpty) {
      nonListContent = const Center(child: Text('Nenhum conteúdo encontrado.'));
    } else {
      // Se tiver conteúdo, nonListContent é nulo e usaremos o SliverList
      nonListContent = const SizedBox.shrink();
    }

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // 1. AppBar Dinâmica (SliverAppBar) - MANTIDA
          SliverAppBar(
            pinned: true,
            expandedHeight: appState.isSelecting ? 100.0 : 60.0,
            backgroundColor: Colors.indigo,
            foregroundColor: Colors.white,
            centerTitle: true,
            title: appState.isSelecting
                ? const Text('Modo de Seleção',
                    style: TextStyle(fontWeight: FontWeight.bold))
                : const Text('Norma – Jornada e Frequência',
                    style: TextStyle(fontWeight: FontWeight.bold)),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: EdgeInsets.zero,
              centerTitle: true,
              title: appState.isSelecting
                  ? Container(
                      alignment: Alignment.bottomCenter,
                      padding: const EdgeInsets.only(bottom: 15),
                      child: Text(
                          'Selecionados: ${appState.selectedContentIds.length}',
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white)),
                    )
                  : null,
            ),
            leading: appState.isSelecting
                ? IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: appState.clearSelection,
                  )
                : null,
            actions: [
              if (appState.isSelecting)
                IconButton(
                  icon: const Icon(Icons.share, color: Colors.white),
                  onPressed: () =>
                      _shareBatchContent(context, appState.selectedContent),
                  tooltip: 'Compartilhar em Lote',
                )
            ],
          ),

          // 2. CORREÇÃO DE LAYOUT: Renderiza o conteúdo (Capítulos ou Mensagem)

          if (chapters.isNotEmpty)
            // Se houver capítulos, usa o SliverList para renderizá-los
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final chapter = chapters[index];

                  // Adiciona um separador visual entre os ChapterExpanders
                  if (index > 0) {
                    return Column(
                      children: [
                        Divider(
                          color: Colors.indigo.shade200,
                          thickness: 1.2,
                          height: 24,
                        ),
                        ChapterExpander(chapter: chapter),
                      ],
                    );
                  }

                  return ChapterExpander(chapter: chapter);
                },
                childCount: chapters.length,
              ),
            )
          else
            // Se não houver capítulos (carregando/erro/vazio), usa SliverFillRemaining
            // para exibir a mensagem no centro da tela.
            SliverFillRemaining(
              hasScrollBody:
                  false, // Não permite rolagem extra para o conteúdo de erro/loading
              child: nonListContent,
            ),
        ],
      ),
    );
  }

// ... (Restante da classe _NormaScreenState, inalterada)
  // Funções auxiliares...
}
