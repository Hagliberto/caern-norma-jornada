// [main.dart]
import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; 
import 'core/app_state.dart'; 
import 'widgets/norma_home_screen.dart'; // NOVO: Centraliza o BottomNavBar

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => AppState(),
      child: const NormaApp(),
    ),
  );
}

class NormaApp extends StatelessWidget {
  const NormaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Norma – Jornada e Frequência',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Tema Mais Moderno/Fluido
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          primary: Colors.indigo,
          secondary: Colors.amber,
          surface: Colors.grey.shade50, // Cor de fundo suave
        ),
        scaffoldBackgroundColor: Colors.grey.shade100,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.indigo,
          foregroundColor: Colors.white,
          elevation: 0, // Remove a sombra padrão para um visual mais plano
        ),
      ),
      home: const NormaHomeScreen(), // Usa a nova tela de navegação
    );
  }
}