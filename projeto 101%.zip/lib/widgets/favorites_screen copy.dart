// projeto.zip/lib/widgets/favorites_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';
import 'content_tile.dart'; // Será criado no próximo passo

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final favorites = Provider.of<AppState>(context).favorites;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Conteúdo Favorito'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: favorites.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.star_border, size: 60, color: Colors.grey),
                  SizedBox(height: 10),
                  Text('Você ainda não adicionou nenhum favorito.'),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                final content = favorites[index];
                return ContentTile(content: content);
              },
            ),
    );
  }
}