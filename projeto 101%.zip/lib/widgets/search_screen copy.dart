// projeto.zip/lib/widgets/search_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';
import 'content_tile.dart'; // Será criado no próximo passo

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final results = appState.filteredContent;

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          onChanged: appState.setQuery,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Buscar na norma...',
            border: InputBorder.none,
            hintStyle: TextStyle(color: Colors.white70),
          ),
          style: const TextStyle(color: Colors.white, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () {
              appState.setQuery(''); // Limpa a busca
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
      body: results.isEmpty && appState.query.isNotEmpty
          ? const Center(child: Text('Nenhum resultado encontrado.'))
          : ListView.builder(
              itemCount: results.length,
              itemBuilder: (context, index) {
                final content = results[index];
                return ContentTile(content: content);
              },
            ),
    );
  }
}