import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart'; // NOVO: Para o compartilhamento WhatsApp
import '../core/app_state.dart';

class ChapterExpander extends StatelessWidget {
  final Map<String, dynamic> chapter;

  const ChapterExpander({super.key, required this.chapter});

  // Função Simples de Compartilhamento (Adaptada para WhatsApp)
  void _shareContent(BuildContext context, String reference, String content) async {
    final String textToShare = 
        '*Norma – Jornada e Frequência CAERN*\n\n*Referência:* $reference\n\n$content';
    
    final String encodedText = Uri.encodeComponent(textToShare);
    final whatsappUrl = Uri.parse('whatsapp://send?text=$encodedText');
    final fallbackUrl = Uri.parse('https://wa.me/?text=$encodedText');

    try {
      if (await canLaunchUrl(whatsappUrl)) {
        await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(fallbackUrl)) {
        await launchUrl(fallbackUrl, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível abrir o WhatsApp. Tente usar o compartilhamento padrão.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao tentar compartilhar: $e')),
      );
    }
  }
  
  // Função que tenta mapear um item/parágrafo para um NormaContent para favoritar
  NormaContent? _findNormaContent(BuildContext context, String reference, String content) {
    final appState = Provider.of<AppState>(context, listen: false);
    
    // CORREÇÃO: Usando o getter público 'allContent'
    try {
      return appState.allContent.firstWhere(
        (c) => c.reference == reference && c.content == content,
        orElse: () => throw Exception(),
      );
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final directArticles = chapter['articles'] ?? [];
    final sections = chapter['sections'] ?? [];
    final String chapTitle = chapter['chapter'];

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ExpansionTile(
        initiallyExpanded: false,
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: const Icon(Icons.book, color: Colors.indigo),
        title: Text(
          '$chapTitle – ${chapter['title'] ?? ''}',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15.5,
          ),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
             // Compartilhar Capítulo
             IconButton(
              icon: const Icon(Icons.share, size: 20, color: Colors.grey),
              onPressed: () => _shareContent(context, chapTitle, chapter['title'] ?? ''),
              tooltip: 'Compartilhar Capítulo',
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (var art in directArticles) ...[
                  _buildArticleTile(context, art, chapTitle),
                  const SizedBox(height: 10),
                ],
                for (var section in sections)
                  _buildSection(context, section, chapTitle),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(BuildContext context, Map<String, dynamic> section, String chapTitle) {
    final articles = section['articles'] ?? [];
    final String sectionRef = '$chapTitle - ${section['text']}';
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 8, left: 4),
          child: Text(
            section['text'] ?? '',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14.0,
              color: Colors.indigo.shade800,
            ),
          ),
        ),
        for (var art in articles) ...[
          _buildArticleTile(context, art, sectionRef),
          const SizedBox(height: 10),
        ],
      ],
    );
  }

  Widget _buildArticleTile(BuildContext context, Map<String, dynamic> article, String baseRef) {
    final items = article['items'] ?? [];
    final paragraphs = article['paragraphs'] ?? [];
    final String artText = article['text'] ?? '';
    final String artContent = article['content'] ?? '';
    final String artRef = '$baseRef - $artText';
    
    final artNormaContent = _findNormaContent(context, artRef, artContent);
    final appState = Provider.of<AppState>(context);
    final bool isFav = artNormaContent != null && appState.isFavorite(artNormaContent.id);

    return Card(
      elevation: 1,
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        leading: const Icon(Icons.balance, color: Colors.indigo),
        title: Text(
          artText,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: artContent.isNotEmpty
            ? Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Text(
                  artContent,
                  style: TextStyle(color: Colors.grey.shade700, fontSize: 13.5),
                ),
              )
            : null,
        // Ações para o Artigo
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Favoritar Artigo
            IconButton(
              icon: Icon(
                isFav ? Icons.star : Icons.star_border,
                size: 20,
                color: isFav ? Colors.amber : Colors.grey,
              ),
              onPressed: () {
                if (artNormaContent != null) {
                  appState.toggleFavorite(artNormaContent);
                } else {
                   ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Conteúdo do Artigo não pode ser favoritado separadamente da lista plana.')),
                  );
                }
              },
              tooltip: isFav ? 'Remover Artigo' : 'Favoritar Artigo',
            ),
            // Compartilhar Artigo
            IconButton(
              icon: const Icon(Icons.share, size: 20, color: Colors.grey),
              onPressed: () => _shareContent(context, artRef, artContent),
              tooltip: 'Compartilhar Artigo',
            ),
          ],
        ),
        children: [
          if (items.isNotEmpty)
            _buildSectionList(context, items, 'Itens', Icons.list_alt, artRef), 
          if (paragraphs.isNotEmpty)
            _buildSectionList(context, paragraphs, 'Parágrafos', Icons.format_align_left, artRef), 
        ],
      ),
    );
  }

  Widget _buildSectionList(BuildContext context, List<dynamic> list, String label, IconData icon, String baseRef) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, bottom: 8, right: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: Colors.indigo.shade400),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: Colors.indigo.shade600,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          for (var entry in list)
            _buildEntryWithActions(context, entry, baseRef),
        ],
      ),
    );
  }
  
  Widget _buildEntryWithActions(BuildContext context, dynamic entry, String baseRef) {
    final entryText = _formatEntry(entry);
    final String index = (entry is Map<String, dynamic> && entry.containsKey('index')) ? entry['index'] : '';
    final String content = (entry is Map<String, dynamic>) ? entry['definition'] ?? entry['content'] ?? '' : entryText;
    final String itemRef = '$baseRef - $index';
    
    final itemNormaContent = _findNormaContent(context, itemRef, content);
    final appState = Provider.of<AppState>(context);
    final bool isFav = itemNormaContent != null && appState.isFavorite(itemNormaContent.id);

    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              entryText,
              style: const TextStyle(fontSize: 13.5, height: 1.4),
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Favoritar Item/Parágrafo
              IconButton(
                icon: Icon(
                  isFav ? Icons.star : Icons.star_border,
                  size: 18,
                  color: isFav ? Colors.amber : Colors.grey,
                ),
                onPressed: () {
                  if (itemNormaContent != null) {
                    appState.toggleFavorite(itemNormaContent);
                  } else {
                     ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Conteúdo do Item/Parágrafo não pode ser favoritado separadamente da lista plana.')),
                    );
                  }
                },
                tooltip: isFav ? 'Remover Item/Parágrafo' : 'Favoritar Item/Parágrafo',
              ),
              // Compartilhar Item/Parágrafo
              IconButton(
                icon: const Icon(Icons.share, size: 18, color: Colors.grey),
                onPressed: () => _shareContent(context, itemRef, content),
                tooltip: 'Compartilhar Item/Parágrafo',
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatEntry(dynamic entry) {
    if (entry is Map<String, dynamic>) {
      if (entry.containsKey('sub_items') && entry['sub_items'] is List) {
        final term = entry['term'] != null ? '${entry['term']}: ' : '';
        final index = entry['index'] != null ? '${entry['index']} - ' : '';
        
        final subItemsFormatted = (entry['sub_items'] as List)
            .map((sub) => _formatEntry(sub))
            .join('\n      '); 
        
        return '$index$term\n    $subItemsFormatted';
      }

      final index = entry['index'] != null ? '${entry['index']} ' : '';
      final term = entry['term'] != null ? '${entry['term']}: ' : '';
      final def = entry['definition'] ?? entry['content'] ?? '';
      return '$index$term$def';
    }
    return entry.toString();
  }
}