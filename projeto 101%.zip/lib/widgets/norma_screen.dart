import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; 
import '../core/app_state.dart'; 
import 'chapter_expander.dart';
import 'search_screen.dart'; 
import 'favorites_screen.dart'; 

class NormaScreen extends StatefulWidget {
  const NormaScreen({super.key});

  @override
  State<NormaScreen> createState() => _NormaScreenState();
}

class _NormaScreenState extends State<NormaScreen> {

  @override
  void initState() {
    super.initState();
    // Inicia o carregamento dos dados via AppState
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppState>(context, listen: false).loadFromAssets();
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    // CORREÇÃO: Usando o getter público 'rawChapters'
    final chapters = appState.rawChapters; 

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Norma – Jornada e Frequência',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          // Botão de Busca
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const SearchScreen()),
              );
            },
          ),
          // Botão de Favoritos
          IconButton(
            icon: const Icon(Icons.star),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const FavoritesScreen()),
              );
            },
          ),
        ],
      ),
      body: appState.isLoading
          ? const Center(child: CircularProgressIndicator())
          : appState.error != null
              ? Center(
                  child: Text(
                    'Erro ao carregar a norma:\n${appState.error}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : chapters.isEmpty
                  ? const Center(child: Text('Nenhum conteúdo encontrado.'))
                  : ListView.separated(
                      padding: const EdgeInsets.all(8.0),
                      separatorBuilder: (_, __) => Divider(
                        color: Colors.indigo.shade200,
                        thickness: 1.2,
                        height: 24,
                      ),
                      itemCount: chapters.length,
                      itemBuilder: (context, index) {
                        final chapter = chapters[index];
                        return ChapterExpander(chapter: chapter);
                      },
                    ),
    );
  }
}