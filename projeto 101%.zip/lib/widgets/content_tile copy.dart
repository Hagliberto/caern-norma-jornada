// projeto.zip/lib/widgets/content_tile.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// import 'package:share_plus/share_plus.dart'; // Pacote necessário para compartilhar
import '../core/app_state.dart';

class ContentTile extends StatelessWidget {
  final NormaContent content;

  const ContentTile({super.key, required this.content});

  // Função Simples de Compartilhamento
  void _shareContent(BuildContext context) {
    final String textToShare = 
        'Norma – Jornada e Frequência\nReferência: ${content.reference}\n\nConteúdo: ${content.content}';
    
    // NOTA: Para funcionar, você precisaria adicionar o pacote 'share_plus' ao pubspec.yaml
    // e usar: Share.share(textToShare);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Conteúdo Copiado para Compartilhamento (Simulado): $textToShare')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final bool isFav = appState.isFavorite(content.id);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Referência (Ex: CAP. IV - Seção I: Das premissas... - Art. 19 Premissas)
            Text(
              content.reference,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 13,
                color: Colors.indigo.shade600,
              ),
            ),
            const SizedBox(height: 6),
            // Conteúdo (Texto do Artigo/Item/Parágrafo)
            Text(
              content.content,
              style: const TextStyle(fontSize: 14, height: 1.5),
            ),
            
            // Ações: Favoritar e Compartilhar
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: Icon(
                    isFav ? Icons.star : Icons.star_border,
                    color: isFav ? Colors.amber : Colors.grey,
                  ),
                  onPressed: () => appState.toggleFavorite(content),
                  tooltip: isFav ? 'Remover dos favoritos' : 'Adicionar aos favoritos',
                ),
                IconButton(
                  icon: const Icon(Icons.share, color: Colors.grey),
                  onPressed: () => _shareContent(context),
                  tooltip: 'Compartilhar',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}