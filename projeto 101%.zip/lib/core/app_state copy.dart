// lib/core/app_state.dart
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Definindo a Estrutura de Conteúdo para suportar a busca e favoritos
class NormaContent {
  final String id;
  final String content;
  final String reference; // Ex: "CAP. I - Art. 1º"
  
  // Para armazenar no SharedPreferences
  Map<String, dynamic> toJson() => {'id': id, 'content': content, 'reference': reference};
  factory NormaContent.fromJson(Map<String, dynamic> json) => 
    NormaContent(id: json['id'] as String, content: json['content'] as String, reference: json['reference'] as String);

  NormaContent({required this.id, required this.content, required this.reference});
}

// Classe de gerenciamento de estado
class AppState extends ChangeNotifier {
  List<dynamic> _rawChapters = []; // O JSON cru (para manter compatibilidade com widgets)
  List<dynamic> get rawChapters => _rawChapters; // <<< CORREÇÃO ADICIONADA AQUI

  // Lista plana de todo o conteúdo para busca e favoritos
  List<NormaContent> _allContent = [];
  List<NormaContent> get allContent => _allContent; // <<< CORREÇÃO ADICIONADA AQUI

  // Busca
  String _query = '';
  String get query => _query;

  List<NormaContent> get filteredContent {
    if (_query.isEmpty) {
      return [];
    }
    return _allContent
        .where((c) => c.content.toLowerCase().contains(_query.toLowerCase()))
        .toList();
  }

  // Favoritos
  final List<String> _favoriteIds = []; // IDs de conteúdo favoritos
  List<NormaContent> get favorites {
    return _allContent.where((c) => _favoriteIds.contains(c.id)).toList();
  }
  
  bool isFavorite(String contentId) => _favoriteIds.contains(contentId);
  
  // Estado
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _error;
  String? get error => _error;

  // Inicialização e Carga de Dados
  Future<void> loadFromAssets() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      // 1. Carregar JSON (usando o método auxiliar)
      final raw = await rootBundle.loadString('assets/norma_data_completa.json');
      _rawChapters = jsonDecode(raw) as List<dynamic>;
      
      // 2. Popular a lista plana de conteúdo (para busca e favoritos)
      _allContent = _extractAllContent(_rawChapters);
      
      // 3. Carregar Favoritos persistidos
      await _loadFavorites();
      
    } catch (e) {
      _error = 'Falha ao carregar dados: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Extrai todo o texto relevante (Artigos, Itens, Parágrafos) para uma lista plana
  List<NormaContent> _extractAllContent(List<dynamic> chapters) {
    final List<NormaContent> list = [];
    
    // Contadores para IDs únicos (garantindo que cada elemento tenha um ID)
    int contentCounter = 0; 
    
    for (var chapter in chapters) {
      final String chapTitle = chapter['chapter'];
      
      // Funções auxiliares para processar artigos e seções
      void processArticles(List<dynamic> articles, String currentRef) {
        for (var art in articles) {
          final String artText = art['text'];
          final String baseRef = '$currentRef - $artText';

          // Adicionar o Conteúdo principal do Artigo
          if (art['content'] != null) {
            list.add(NormaContent(
                id: (contentCounter++).toString(),
                content: art['content'],
                reference: baseRef));
          }

          // Adicionar Itens
          if (art['items'] != null) {
            for (var item in art['items']) {
              final String itemRef = '$baseRef - ${item['index']}';
              // Trata sub_items aninhados (Cap. VI)
              if (item['sub_items'] != null) {
                for (var sub in item['sub_items']) {
                  final String subRef = '$itemRef - ${sub['index']}';
                  list.add(NormaContent(
                      id: (contentCounter++).toString(),
                      content: sub['definition'],
                      reference: subRef));
                }
              } else {
                list.add(NormaContent(
                    id: (contentCounter++).toString(),
                    content: item['definition'] ?? item['content'],
                    reference: itemRef));
              }
            }
          }

          // Adicionar Parágrafos
          if (art['paragraphs'] != null) {
            for (var p in art['paragraphs']) {
              final String pRef = '$baseRef - ${p['index']}';
              list.add(NormaContent(
                  id: (contentCounter++).toString(),
                  content: p['content'],
                  reference: pRef));
            }
          }
        }
      }

      // 1. Processar Capítulos com artigos diretos (Cap. I, II, V, etc.)
      if (chapter['articles'] != null) {
        processArticles(chapter['articles'], chapTitle);
      }
      
      // 2. Processar Capítulos com seções (Cap. III, IV)
      if (chapter['sections'] != null) {
        for (var section in chapter['sections']) {
          final String sectionRef = '$chapTitle - ${section['text']}';
          if (section['articles'] != null) {
            processArticles(section['articles'], sectionRef);
          }
        }
      }
    }
    return list;
  }

  // --- Funções de Estado (Setters) ---
  
  void setQuery(String q) {
    _query = q.trim();
    notifyListeners();
  }

  // --- Gerenciamento de Favoritos ---

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final favs = prefs.getStringList('favoriteContentIds');
    _favoriteIds.clear();
    if (favs != null) {
      _favoriteIds.addAll(favs);
    }
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favoriteContentIds', _favoriteIds);
  }

  void toggleFavorite(NormaContent content) {
    if (_favoriteIds.contains(content.id)) {
      _favoriteIds.remove(content.id);
    } else {
      _favoriteIds.add(content.id);
    }
    _saveFavorites();
    notifyListeners();
  }
}