import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

Future<List<dynamic>> loadNormaData() async {
  try {
    final String response = await rootBundle.loadString('assets/norma_data_completa.json');
    final data = json.decode(response);
    if (data is List) {
      return data;
    } else {
      throw Exception('Formato inválido: o JSON deve ser uma lista.');
    }
  } catch (e) {
    throw Exception('Erro ao carregar norma_data_completa.json: $e');
  }
}
