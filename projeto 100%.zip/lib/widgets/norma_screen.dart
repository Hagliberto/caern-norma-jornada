import 'package:flutter/material.dart';
import '../data/norma_data.dart';
import 'chapter_expander.dart';

class NormaScreen extends StatefulWidget {
  const NormaScreen({super.key});

  @override
  State<NormaScreen> createState() => _NormaScreenState();
}

class _NormaScreenState extends State<NormaScreen> {
  late Future<List<dynamic>> normaFuture;

  @override
  void initState() {
    super.initState();
    normaFuture = loadNormaData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Norma – Jornada e Frequência',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: normaFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
              child: Text(
                'Erro ao carregar a norma:\n${snapshot.error}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red),
              ),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Nenhum conteúdo encontrado.'));
          }

          final chapters = snapshot.data!;
          return ListView.separated(
            padding: const EdgeInsets.all(8.0),
            separatorBuilder: (_, __) => Divider(
              color: Colors.indigo.shade200,
              thickness: 1.2,
              height: 24,
            ),
            itemCount: chapters.length,
            itemBuilder: (context, index) {
              final chapter = chapters[index];
              return ChapterExpander(chapter: chapter);
            },
          );
        },
      ),
    );
  }
}
