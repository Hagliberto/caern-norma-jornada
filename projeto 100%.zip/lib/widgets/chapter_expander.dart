import 'package:flutter/material.dart';

class ChapterExpander extends StatelessWidget {
  final Map<String, dynamic> chapter;

  const ChapterExpander({super.key, required this.chapter});

  @override
  Widget build(BuildContext context) {
    // 1. Acesso direto aos artigos (para Capítulos sem seções, como I, II, V, VI, VII)
    final directArticles = chapter['articles'] ?? [];
    
    // 2. Acesso às seções (para Capítulos com seções, como III, IV)
    final sections = chapter['sections'] ?? [];

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ExpansionTile(
        initiallyExpanded: false,
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: const Icon(Icons.book, color: Colors.indigo),
        title: Text(
          // Trata capítulos que podem não ter o campo 'chapter' (embora o JSON fornecido tenha)
          '${chapter['chapter'] ?? ''} – ${chapter['title'] ?? ''}',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15.5,
          ),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Caso 1: Artigos diretos (Ex: Capítulo I)
                for (var art in directArticles) ...[
                  _buildArticleTile(art),
                  const SizedBox(height: 10),
                ],

                // Caso 2: Seções (Ex: Capítulo IV)
                for (var section in sections)
                  _buildSection(section),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(Map<String, dynamic> section) {
    final articles = section['articles'] ?? [];
    // O texto da Seção (h3) pode ser exibido como um título separado ou dentro de um Card
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 8, left: 4),
          child: Text(
            section['text'] ?? '',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14.0,
              color: Colors.indigo.shade800,
            ),
          ),
        ),
        for (var art in articles) ...[
          _buildArticleTile(art),
          const SizedBox(height: 10),
        ],
      ],
    );
  }

  Widget _buildArticleTile(Map<String, dynamic> article) {
    final items = article['items'] ?? [];
    final paragraphs = article['paragraphs'] ?? [];

    return Card(
      elevation: 1,
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        leading: const Icon(Icons.balance, color: Colors.indigo),
        // Exibe o título (ex: Art. 19 Premissas)
        title: Text(
          article['text'] ?? '',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        // Exibe o conteúdo (ex: Consideram-se premissas para realização de hora extra:)
        subtitle: article['content'] != null
            ? Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Text(
                  article['content'],
                  style: TextStyle(color: Colors.grey.shade700, fontSize: 13.5),
                ),
              )
            : null,
        children: [
          // Conteúdo expandido: Itens e Parágrafos
          if (items.isNotEmpty)
            _buildSectionList(items, 'Itens', Icons.list_alt),
          if (paragraphs.isNotEmpty)
            _buildSectionList(paragraphs, 'Parágrafos', Icons.format_align_left),
        ],
      ),
    );
  }

  Widget _buildSectionList(List<dynamic> list, String label, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, bottom: 8, right: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: Colors.indigo.shade400),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: Colors.indigo.shade600,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          for (var entry in list)
            Padding(
              padding: const EdgeInsets.only(left: 8, bottom: 4),
              child: Text(
                _formatEntry(entry),
                style: const TextStyle(fontSize: 13.5, height: 1.4),
              ),
            ),
        ],
      ),
    );
  }

  String _formatEntry(dynamic entry) {
    if (entry is Map<String, dynamic>) {
      // Ajuste para lidar com sub_items aninhados (Ex: Capítulo VI, Art. 56)
      if (entry.containsKey('sub_items') && entry['sub_items'] is List) {
        final term = entry['term'] != null ? '${entry['term']}: ' : '';
        final index = entry['index'] != null ? '${entry['index']} - ' : '';
        
        // Retorna o Termo/Index principal e aninha os sub-itens
        return '$index$term' + (entry['sub_items'] as List)
            .map((sub) => _formatEntry(sub))
            .join('\n    '); // Formatação básica para sub-itens
      }

      final index = entry['index'] != null ? '${entry['index']} ' : '';
      final term = entry['term'] != null ? '${entry['term']}: ' : '';
      final def = entry['definition'] ?? entry['content'] ?? '';
      return '$index$term$def';
    }
    return entry.toString();
  }
}