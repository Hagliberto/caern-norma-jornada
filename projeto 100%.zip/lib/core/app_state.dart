// lib/core/app_state.dart
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/foundation.dart';

// Ensure that NormaChapter is defined in norma_data.dart and properly exported.

class AppState extends ChangeNotifier {
  // Conteúdo carregado do JSON
  List<NormaChapter> _chapters = [];
  List<NormaChapter> get chapters => _chapters;

  // Busca
  String _query = '';
  String get query => _query;

  // Estado
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _error;
  String? get error => _error;

  Future<void> loadFromAssets() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final raw = await rootBundle.loadString('assets/norma_data_completa.json');
      final List<dynamic> data = jsonDecode(raw) as List<dynamic>;
      _chapters = data
          .map((e) => NormaChapter.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      _error = 'Falha ao carregar dados: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void setQuery(String q) {
    _query = q.trim();
    notifyListeners();
  }
}

class NormaChapter {
  // Add fields according to your JSON structure, for example:
  final String title;
  final String content;

  NormaChapter({required this.title, required this.content});

  // Update the factory constructor according to your JSON structure
  factory NormaChapter.fromJson(Map<String, dynamic> json) {
    return NormaChapter(
      title: json['title'] as String,
      content: json['content'] as String,
    );
  }
}
