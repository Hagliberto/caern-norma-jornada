import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart'; 
import '../core/app_state.dart';

class ContentTile extends StatelessWidget {
  final NormaContent content;
  // NOVOS campos para seleção na tela de Favoritos
  final bool isSelectable;
  final bool isSelected;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;


  const ContentTile({
    super.key, 
    required this.content,
    this.isSelectable = false, // Padrão: Não selecionável (para resultados de busca)
    this.isSelected = false,
    this.onTap,
    this.onLongPress,
  });

  // Função para Compartilhamento (Adaptada para WhatsApp)
  void _shareContent(BuildContext context) async {
    final String textToShare = 
        '*Norma – Jornada e Frequência CAERN*\n\n*Referência:* ${content.reference}\n\n${content.content}';
    
    final String encodedText = Uri.encodeComponent(textToShare);
    final whatsappUrl = Uri.parse('whatsapp://send?text=$encodedText');
    final fallbackUrl = Uri.parse('https://wa.me/?text=$encodedText');

    try {
      if (await canLaunchUrl(whatsappUrl)) {
        await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(fallbackUrl)) {
        await launchUrl(fallbackUrl, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível abrir o WhatsApp.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao tentar compartilhar: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final bool isFav = appState.isFavorite(content.id);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      elevation: 1,
      color: isSelected ? Colors.lightBlue.shade50 : Colors.white, // Cor de seleção
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Linha do Título e Checkbox de Seleção
              Row(
                children: [
                  Expanded(
                    child: Text(
                      content.reference,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: Colors.indigo.shade600,
                      ),
                    ),
                  ),
                  if (isSelectable) // Checkbox visível apenas na tela de favoritos se for selecionável
                    Checkbox(
                      value: isSelected,
                      onChanged: (val) {
                        if (onTap != null) onTap!();
                      },
                    ),
                ],
              ),
              const SizedBox(height: 6),
              // Conteúdo (Texto do Artigo/Item/Parágrafo)
              Text(
                // Limita a exibição do conteúdo na lista (para forçar o clique para ver o resto)
                isSelectable 
                  ? (content.content.length > 150 ? '${content.content.substring(0, 150)}...' : content.content)
                  : content.content,
                style: const TextStyle(fontSize: 14, height: 1.5),
              ),
              
              // Ações: Favoritar e Compartilhar
              if (!isSelectable) // Ações só aparecem se não estiver no modo de seleção (usado para busca)
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      icon: Icon(
                        isFav ? Icons.star : Icons.star_border,
                        color: isFav ? Colors.amber : Colors.grey,
                      ),
                      onPressed: () => appState.toggleFavorite(content),
                      tooltip: isFav ? 'Remover dos favoritos' : 'Adicionar aos favoritos',
                    ),
                    IconButton(
                      icon: const Icon(Icons.share, color: Colors.grey),
                      onPressed: () => _shareContent(context),
                      tooltip: 'Compartilhar via WhatsApp',
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}