import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart'; // Para compartilhamento
import '../core/app_state.dart';
import 'content_tile.dart'; 

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  // Estado local para gerenciar a seleção de itens FAVORITOS para compartilhamento em lote.
  final List<String> _selectedFavIds = [];

  void _toggleFavSelection(String id) {
    setState(() {
      if (_selectedFavIds.contains(id)) {
        _selectedFavIds.remove(id);
      } else {
        _selectedFavIds.add(id);
      }
    });
  }

  void _clearFavSelection() {
    setState(() {
      _selectedFavIds.clear();
    });
  }
  
  // Lógica de compartilhamento em lote (reutilizada do NormaScreen, mas com a lista local)
  void _shareBatchFavorites(BuildContext context, List<NormaContent> contentList) async {
    if (contentList.isEmpty) return;

    final StringBuffer buffer = StringBuffer();
    buffer.write('*Norma – Jornada e Frequência CAERN*\n\n');
    buffer.write('--- Conteúdo Favorito Selecionado (${contentList.length} itens) ---\n');
    buffer.write('-----------------------------------------------------\n');

    for (var content in contentList) {
      buffer.write('\n[${content.type}] *Ref: ${content.reference}*\n');
      buffer.write('${content.content}\n');
      buffer.write('-----------------------------------------------------\n');
    }
    
    final String textToShare = buffer.toString();
    final String encodedText = Uri.encodeComponent(textToShare);
    final whatsappUrl = Uri.parse('whatsapp://send?text=$encodedText');
    final fallbackUrl = Uri.parse('https://wa.me/?text=$encodedText');
    
    try {
      if (await canLaunchUrl(whatsappUrl)) {
        await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(fallbackUrl)) {
        await launchUrl(fallbackUrl, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível abrir o WhatsApp.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao tentar compartilhar: $e')),
      );
    }
    
    _clearFavSelection();
  }

  // Diálogo de confirmação para limpar todos os favoritos
  Future<void> _confirmClearFavorites(BuildContext context) async {
    final appState = Provider.of<AppState>(context, listen: false);
    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Limpar Todos os Favoritos?'),
          content: const Text('Tem certeza de que deseja remover todos os itens da sua lista de favoritos?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Limpar'),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      await appState.clearAllFavorites();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Todos os favoritos foram limpos.')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final favorites = appState.favorites;
    final bool isSelectingFav = _selectedFavIds.isNotEmpty;
    
    // Filtra os objetos NormaContent selecionados
    final selectedFavContent = favorites.where((f) => _selectedFavIds.contains(f.id)).toList();

    return Scaffold(
      appBar: AppBar(
        title: isSelectingFav 
          ? Text('Compartilhar: ${selectedFavContent.length} itens')
          : const Text('Conteúdo Favorito'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        leading: isSelectingFav 
          ? IconButton(
              icon: const Icon(Icons.close),
              onPressed: _clearFavSelection,
            )
          : null,
        actions: [
          if (isSelectingFav)
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () => _shareBatchFavorites(context, selectedFavContent),
              tooltip: 'Compartilhar Selecionados',
            )
          else if (favorites.isNotEmpty) // Botão de limpar (discreto)
            IconButton(
              icon: const Icon(Icons.delete_forever),
              onPressed: () => _confirmClearFavorites(context),
              tooltip: 'Limpar Todos os Favoritos',
            ),
        ],
      ),
      body: favorites.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.star_border, size: 60, color: Colors.grey),
                  SizedBox(height: 10),
                  Text('Você ainda não adicionou nenhum favorito.'),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(8.0),
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                final content = favorites[index];
                final isSelected = _selectedFavIds.contains(content.id);
                
                return ContentTile(
                  content: content,
                  isSelectable: true,
                  isSelected: isSelected,
                  // onLongPress para iniciar a seleção
                  onLongPress: () => _toggleFavSelection(content.id),
                  // onTap para seleção OU para exibir o conteúdo completo
                  onTap: isSelectingFav 
                    ? () => _toggleFavSelection(content.id)
                    : () => _showFullContentDialog(context, content),
                );
              },
            ),
    );
  }

  // NOVO: Exibe o conteúdo completo em um diálogo
  void _showFullContentDialog(BuildContext context, NormaContent content) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(content.reference),
          content: SingleChildScrollView(
            child: Text(
              content.content,
              style: const TextStyle(fontSize: 15, height: 1.5),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Fechar'),
            ),
          ],
        );
      },
    );
  }
}