import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; 
import 'core/app_state.dart'; 
import 'widgets/norma_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => AppState(),
      child: const NormaApp(),
    ),
  );
}

class NormaApp extends StatelessWidget {
  const NormaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Norma – Jornada e Frequência',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: Colors.grey.shade100,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.indigo,
          foregroundColor: Colors.white,
        ),
      ),
      home: const NormaScreen(),
    );
  }
}